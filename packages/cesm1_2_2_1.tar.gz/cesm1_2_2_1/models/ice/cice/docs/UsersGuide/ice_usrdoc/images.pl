# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/displaystyle{frac{{min(Deltax,Deltay)}}{{4max(u,v)}}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 ALIGN="MIDDLE" BORDER="0" SRC="|."$dir".q|img1.png"
 ALT="$\displaystyle {\frac{{min(\Delta x, \Delta y)}}{{4 max(u, v)}}}$">|; 

1;

