
// Having a cpp file tricks libtool into using the CXX compiler to link
