#include "YmirToGlimmer.H"

using namespace std;

int
YmirToGlimmer::initDyCore()
{
  cout << "In Ymir initDyCore" << endl;
}

int
YmirToGlimmer::runDyCore()
{
  cout << "In Ymir runDyCore" << endl;
}

int
YmirToGlimmer::deleteDyCore()
{

}

