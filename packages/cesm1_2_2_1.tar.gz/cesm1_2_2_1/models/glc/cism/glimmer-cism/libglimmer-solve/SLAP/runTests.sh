#!/bin/sh

echo 2 | ./dlapqc
