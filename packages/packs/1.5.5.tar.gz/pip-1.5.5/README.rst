pip
===

.. image:: https://pypip.in/v/pip/badge.png
        :target: https://pypi.python.org/pypi/pip

.. image:: https://secure.travis-ci.org/pypa/pip.png?branch=develop
   :target: http://travis-ci.org/pypa/pip

For documentation, see https://pip.pypa.io/
