~~~~~~~~
LineType
~~~~~~~~

.. autoclass:: ESMF.api.constants.LineType
    :members:
    :exclude-members: __new__