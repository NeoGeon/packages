~~~~~~~~~~~~~~
UnmappedAction
~~~~~~~~~~~~~~

.. autoclass:: ESMF.api.constants.UnmappedAction
    :members:
    :exclude-members: __new__