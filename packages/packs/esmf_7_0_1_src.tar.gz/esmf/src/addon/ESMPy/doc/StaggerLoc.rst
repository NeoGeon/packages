~~~~~~~~~~
StaggerLoc
~~~~~~~~~~

.. autoclass:: ESMF.api.constants.StaggerLoc
    :members:
    :exclude-members: __new__