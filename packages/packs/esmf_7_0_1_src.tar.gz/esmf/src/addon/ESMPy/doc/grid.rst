~~~~
Grid
~~~~

.. autoclass:: ESMF.api.grid.Grid
    :members: add_coords, add_item, copy, destroy, get_coords, get_item,
        area, areatype, coords, coord_sys, has_corners,
        lower_bounds, mask, max_index, num_peri_dims, periodic_dim, pole_dim,
        rank, size, staggerloc, type, upper_bounds