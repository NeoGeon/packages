~~~~~~~~~~
DecompFlag
~~~~~~~~~~

.. autoclass:: ESMF.api.constants.DecompFlag
    :members:
    :exclude-members: __new__
