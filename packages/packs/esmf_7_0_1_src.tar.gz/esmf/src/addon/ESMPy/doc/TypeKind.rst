~~~~~~~~
TypeKind
~~~~~~~~

.. autoclass:: ESMF.api.constants.TypeKind
    :members:
    :exclude-members: __new__