~~~~~~~
Manager
~~~~~~~

.. autoclass:: ESMF.api.esmpymanager.Manager
