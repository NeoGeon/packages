~~~~
Mesh
~~~~

.. autoclass:: ESMF.api.mesh.Mesh
    :members: copy, destroy, add_elements, add_nodes, free_memory, get_coords,
        area, coords, coord_sys, mask, rank, size, size_owned