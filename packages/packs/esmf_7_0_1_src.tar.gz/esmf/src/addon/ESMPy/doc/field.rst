~~~~~
Field
~~~~~

.. autoclass:: ESMF.api.field.Field
    :members: copy, destroy, get_area, read,
        data, grid, lower_bounds, name, ndbounds, rank, staggerloc, type,
        upper_bounds, xd
    