~~~~~~~~
NormType
~~~~~~~~

.. autoclass:: ESMF.api.constants.NormType
    :members:
    :exclude-members: __new__