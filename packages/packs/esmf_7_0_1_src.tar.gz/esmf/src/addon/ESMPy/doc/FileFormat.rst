~~~~~~~~~~
FileFormat
~~~~~~~~~~

.. autoclass:: ESMF.api.constants.FileFormat
    :members:
    :exclude-members: __new__
