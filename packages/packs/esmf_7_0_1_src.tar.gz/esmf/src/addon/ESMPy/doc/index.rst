.. ESMPy documentation master file, created by
   sphinx-quickstart on Tue Dec  6 12:05:22 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

=================
Table of Contents
=================

Welcome to ESMPy - The ESMF Python Interface!

.. toctree::
    :maxdepth: 3

    intro
    install
    api
    examples
    appendix

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

