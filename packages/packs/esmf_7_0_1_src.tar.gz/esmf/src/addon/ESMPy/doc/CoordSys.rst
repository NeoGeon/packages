~~~~~~~~
CoordSys
~~~~~~~~

.. autoclass:: ESMF.api.constants.CoordSys
    :members:
    :exclude-members: __new__
