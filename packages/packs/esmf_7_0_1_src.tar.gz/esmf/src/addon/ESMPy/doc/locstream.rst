~~~~~~~~~
LocStream
~~~~~~~~~

.. autoclass:: ESMF.api.locstream.LocStream
    :members: copy, destroy, lower_bounds, name, rank, size, upper_bounds
