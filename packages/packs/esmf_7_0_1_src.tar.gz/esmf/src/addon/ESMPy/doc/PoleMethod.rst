~~~~~~~~~~
PoleMethod
~~~~~~~~~~

.. autoclass:: ESMF.api.constants.PoleMethod
    :members:
    :exclude-members: __new__