~~~~~~~~~~~~
MeshElemType
~~~~~~~~~~~~

.. autoclass:: ESMF.api.constants.MeshElemType
    :members:
    :exclude-members: __new__