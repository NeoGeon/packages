~~~~~~
Region
~~~~~~

.. autoclass:: ESMF.api.constants.Region
    :members:
    :exclude-members: __new__