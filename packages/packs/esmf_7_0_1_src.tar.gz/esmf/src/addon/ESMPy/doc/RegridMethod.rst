~~~~~~~~~~~~
RegridMethod
~~~~~~~~~~~~

.. autoclass:: ESMF.api.constants.RegridMethod
    :members:
    :exclude-members: __new__