~~~~~~~~
GridItem
~~~~~~~~

.. autoclass:: ESMF.api.constants.GridItem
    :members:
    :exclude-members: __new__