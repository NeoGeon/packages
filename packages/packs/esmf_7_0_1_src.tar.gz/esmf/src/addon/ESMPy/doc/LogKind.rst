~~~~~~~
LogKind
~~~~~~~

.. autoclass:: ESMF.api.constants.LogKind
    :members:
    :exclude-members: __new__